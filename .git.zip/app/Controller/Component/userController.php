<?php

class UserController extends AppController{
  function index(){
        
    }
}